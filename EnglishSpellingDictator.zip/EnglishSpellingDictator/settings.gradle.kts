rootProject.name = "EnglishSpellingDictator"
include(":app")
